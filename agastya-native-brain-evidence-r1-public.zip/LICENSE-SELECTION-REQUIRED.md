# License selection — human approval required

Zenodo requires a license for a published record.

Recommended option for public evidence documentation only:
Creative Commons Attribution 4.0 International (CC-BY-4.0)

This recommendation applies only to the public evidence documents in this package. It does not license or disclose:
- model weights
- raw corpus
- full tokenizer artifact
- proprietary architecture/training source code

Do not publish the Zenodo deposit until Rabbit Industries approves the evidence-document license.
