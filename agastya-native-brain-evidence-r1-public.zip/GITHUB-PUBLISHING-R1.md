# GitHub Publication R1

Recommended repository: rabbit-industries/agastya-native-brain-evidence
Recommended visibility: PUBLIC

Publish only the public-safe files in this bundle.

Do not add:
- raw model checkpoints
- private tokenizer vocabulary/merges artifact
- raw corpus
- private architecture/training source
- API keys or infrastructure secrets

Use README-GITHUB.md as README.md.

Create release/tag: v1.0.0-evidence-r1
Attach: agastya-publication-r1.zip

If Zenodo GitHub integration is used later, keep .zenodo.json in the repository. Review/select the evidence-document license before creating the Zenodo release.
